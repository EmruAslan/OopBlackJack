from enum import Enum

class Person:
    def __init__(self, name = " ", address = " ", email = " ", phone = " "):
        self.name = name
        self.address = address
        self.email = email
        self.phone = phone

class SUIT(Enum):
    """Enum class for suits"""
    HEART, SPADE, CLUB, DIAMOND = 1, 2, 3, 4

class AccountStatus(Enum):
    Active, Closed, Cancelled, Blacklisted, NONE = 1, 2, 3, 4, 5
