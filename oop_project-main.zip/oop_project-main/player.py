from abc import ABC
from enums import *

class BasePlayer(ABC):
    def __init__(self, ID, password, balance, status, person):
        pass

    def reset_password(self):
        pass

    def get_hands(self):
        pass

    def add_hand(self, hand):
        pass

    def remove_hand(self, hand):
        pass
class Player(BasePlayer):
    def __init__(self, ID = 0, password = "", balance = 0, status = 1, person = Person()):
        self.__ID = ID
        self.__password = password
        self.__balance = balance
        self.__status = status
        self.__person = person
        self.__hands = []
        self.__bet = 0
        self.__total_cash = 0
        self.__person = person
        
    def reset_password(self, password):
        self.__password = password
        return True
        
    def get_hands(self):
        return self.__hands
    
    def add_hand(self, hand):
        return self.__hands.extend(hand)
    
    def remove_hand(self, hand):
        self.__hands.remove(hand)

    def get_id(self):
        return self.__ID

    def get_password(self):
        return self.__password

    def get_balance(self):
        return self.__balance

    def get_status(self):
        return self.__status
    
    def get_person(self):
        return self.__person
    
    def get_bet(self):
        return self.__bet

    def get_total_cash(self):
        return self.__total_cash

    def set_id(self, ID):
        self.__ID = ID
    
    def set_balance(self, balance):
        self.__balance = balance
    
    def set_status(self, status):
        self.__status = status

    def place_bet(self, bet):
        self.__bet = bet
        
    def set_person(self, person):
        self.__person = person


class Dealer(BasePlayer):
    def __init__(self, ID = 0, password = "123*", balance = 100, status = 1, person = Person()):
        self.__ID = ID
        self.__password = password
        self.__balance = balance
        self.__status = status
        self.__person = person
        self.__hands = []
        self.__bet = 0
        
    def reset_password(self):
        pass
        
    def get_hands(self):
        return self.__hands
    
    def add_hand(self, hand):
        return self.__hands.extend(hand)
    
    def remove_hand(self, hand):
        self.__hands.remove(hand)

    def get_id(self):
        return self.__ID

    def get_password(self):
        return self.__password

    def get_balance(self):
        return self.__balance

    def get_status(self):
        return self.__status
    
    def get_person(self):
        return self.__person
    
    def get_bet(self):
        return self.__bet

    def set_id(self, ID):
        self.__ID = ID
    
    def set_password(self, password):
        self.__password = password
    
    def set_balance(self, balance):
        self.__balance = balance
    
    def set_status(self, status):
        self.__status = status

    def set_person(self, person):
        self.__person = person
