from card import Card
from enums import SUIT

class BlackjackCard(Card):
    """Constructor"""
    def __init__(self, suit, face_value):
        super().__init__(suit, face_value)
        self.__game_value = face_value
        if self.__game_value > 10:
        # 11 = Joker, 12 = Queen, 13 = King 
            self.__game_value = 10

    def get_game_value(self):
        """Function returning cards value in blackjack"""
        return self.__game_value
