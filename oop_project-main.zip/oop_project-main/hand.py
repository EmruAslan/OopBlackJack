from BlackjackCard import BlackjackCard
class Hand:
    def __init__(self, blackjack_card1, blackjackcard2):
        self.__cards = [blackjack_card1,blackjackcard2]

    def add_card(self,card):
        self.__cards.append(card)

    def get_cards(self):
        return self.__cards

    def get_scores(self):
        totals = [0]

        for card in self.__cards:
            new_totals = []
            for score in totals:
                new_totals.append(card.get_game_value() + score)
                if card.get_game_value() == 1:
                    new_totals.append(11 + score)

            totals = new_totals

        return totals

    # get highest score which is less than or equal to 21
    def resolve_score(self):
        scores = self.get_scores()
        best_score = 0
        for score in scores:
            if score <= 21 and score > best_score:
                best_score = score

        return best_score

hand = Hand(BlackjackCard(1,10),BlackjackCard(2,1))
hand.add_card(BlackjackCard(1,1))
# hand.add_card(BlackjackCard(1,9))
# hand.add_card(BlackjackCard(2,1))
cards = hand.get_cards()
for card in cards:
    print(card.get_game_value())
print(hand.get_scores())
print(hand.resolve_score())