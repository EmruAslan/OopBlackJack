import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime 
from st_btn_select import st_btn_select

st.title('Blackjack')

if "users_list" not in st.session_state:
    users_list = []
    st.write(users_list)
    st.session_state.users_list = users_list
    st.write(users_list)


page = st_btn_select(
      ('Home', 'Üye Kayıt', 'Üye Giriş'),
      nav=False,
      #format_func=lambda name: name.capitalize(),
    )

class Creat_Person:
    def __init__(self, fname, lname, password):
        self.firstname = fname
        self.lastname = lname
        self.password = password
    def Person_Print(self):
        st.write(self.firstname, self.lastname)

if page == 'Üye Kayıt':

    col1, col2, col3 = st.columns(3)

    with col1:

        isim = st.text_input(
            "isim"
        )

    with col2:
        soyisim = st.text_input(
            "soyisim"
        )

    with col3:
        password = st.text_input("Password:", value="", type="password")

    a = st.button("kaydet")
    if a:
        st.write(isim, soyisim, password)
        created_user = Creat_Person(isim, soyisim, password)
        temp_list = [[(created_user.firstname), (created_user.lastname), (created_user.password)]]
        users_list = st.session_state.users_list
        users_list.append(temp_list)
        st.session_state.users_list = users_list
        
        st.write(users_list)
        st.write("--")
        st.write(temp_list)
        
if page == 'Üye Giriş':
    col1, col2, col3 = st.columns(3)

    with col1:

        isim = st.text_input(
            "isim"
        )

    with col2:
        soyisim = st.text_input(
            "soyisim"
        )

    with col3:
        password = st.text_input("Password:", value="", type="password")
    
    b = st.button("giriş")
    if b:
        check_list = [[isim,soyisim,password]]
        users_list = st.session_state.users_list
        for i in range(0,len(users_list)):
            s =0
            if check_list == users_list[i]:
                st.write("giriş başarılı hoş geldiniz", users_list[i][0][0])
                s=1
        if s==0:
            st.write("giriş başarısız")
    #users_list = st.session_state.users_list
    #st.write(users_list[0][0][0])
