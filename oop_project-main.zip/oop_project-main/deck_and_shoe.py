import random
from datetime import datetime
from card import SUIT
from BlackjackCard import BlackjackCard
# from .constants import *

class Deck:
    def __init__(self):
        self.__cards = []
        # no attribute today
        # self.__creation_date = datetime.now()
        for value in range(1, 14):
            for suit in SUIT:
                self.__cards.append(BlackjackCard(suit, value))

    def get_cards(self):
        """Returns a list of cards."""
        return self.__cards

    def print_cards(self):
        """Prints cards in the list"""
        for obj in self.__cards:
            print(obj.get_suit(), obj.get_game_value())

class Shoe:
    def __init__(self, number_of_decks):
        self.__cards = []    # list of decks 
        # [ [1,2,3...], [1,2,3...] ]
        self.__number_of_decks = number_of_decks
        self.create_shoe()
        self.shuffle()
        self.print_cards()
        print(len(self.__cards))

    def create_shoe(self):
        """Creates a shoe, which contains multiple"""
        for i in range(self.__number_of_decks):
            self.__cards.extend(Deck().get_cards()) 

    def shuffle(self):
        card_count = len(self.__cards)
        random.shuffle(self.__cards)

    # Get the next card from the shoe
    def deal_card(self):
        if len(self.__cards) == 0:
            self.create_shoe()
        return self.__cards.remove(self.__cards[0])

    def get_number_of_decks(self):
        return self.__number_of_decks

    def get_cards_shoe(self):
        return self.__cards

    def print_cards(self):
        """Prints cards in the list"""
        for obj in self.__cards:
            print(obj.get_suit(), obj.get_game_value())

# shoe = Shoe(1)
# print(len(shoe.get_cards_shoe()))
# shoe.print_cards()
# print("kart silme:")
# shoe.deal_card()
# print("sildikten sonra:")
# shoe.print_cards()
